# DailyQuests

Tägliche Quests für **Paper 26.2** (Java 25) mit XP-Belohnung, Fortschrittsanzeige (BossBar) und optionalem Zeitlimit.

## Funktionen

- Jeder Spieler bekommt **alle 24h neue Quests** (Reset-Uhrzeit und Zeitzone in der `config.yml`)
- **3 Quests zur Auswahl** (bei `one-per-difficulty` je eine leichte, mittlere und schwere)
- Quests per **Menü annehmen** (Linksklick) oder **abbrechen** (Rechtsklick)
- **Fortschrittsanzeige** als BossBar (pro aktiver Quest) und im Menü als Balken
- Optionales **Zeitlimit** pro Quest, ab dem Annehmen. Läuft die Zeit ab, gilt die Quest für den Tag als fehlgeschlagen
- **Belohnung in Erfahrungspunkten (XP)** bei Abschluss, mit Titel und Sound
- Quest-Typen: Blöcke abbauen, Blöcke platzieren, Mobs besiegen, angeln, craften, schmelzen, Tiere züchten, Strecke laufen
- Alle Quests und Texte frei konfigurierbar (`quests.yml`, `config.yml`, MiniMessage-Format)
- Anti-Exploit: selbst platzierte Blöcke zählen beim Abbauen nicht, kein Fortschritt im Kreativmodus

## Bauen

Voraussetzung: **JDK 25** und Gradle (oder der mitgelieferte Wrapper `./gradlew`).

```bash
./gradlew build
```

Die fertige Datei liegt danach in `build/libs/DailyQuests-1.0.0.jar`. Sie kommt in den `plugins`-Ordner des Paper-26.2-Servers.

Die Paper-API wird als `io.papermc.paper:paper-api:26.2.build.+` geladen. Falls du eine feste Version willst, trage in `build.gradle.kts` z.B. `26.2.build.116` ein.

## Befehle und Rechte

| Befehl | Beschreibung | Recht |
|---|---|---|
| `/quests` (`/dq`) | Quest-Menü öffnen | `dailyquests.use` (Standard: alle) |
| `/quests reload` | Konfiguration und Quests neu laden | `dailyquests.admin` |
| `/quests reroll [spieler]` | Quests sofort neu auslosen | `dailyquests.admin` |

## Eigene Quests

In `plugins/DailyQuests/quests.yml`:

```yaml
quests:
  diamond_digger:
    name: "<aqua>Diamantenrausch"
    description: "Baue innerhalb von 60 Minuten 8 Diamanterze ab."
    type: BREAK_BLOCK
    targets: [diamond_ore, deepslate_diamond_ore]   # "#logs" = Tag, weglassen = alles
    amount: 8
    xp: 200
    time-limit-minutes: 60      # 0 = kein Zeitlimit
    difficulty: HARD            # EASY | MEDIUM | HARD
    icon: DIAMOND
```

Nach Änderungen genügt `/quests reload`.

## Hinweise

- Das Zeitlimit läuft in Echtzeit weiter, auch wenn der Spieler offline ist.
- Zum Testen: `/quests reroll` lost neue Quests aus, ohne auf den Tageswechsel zu warten.
- Spielerdaten liegen in `plugins/DailyQuests/data/<UUID>.yml`.
