package de.dailyquests;

/** Zustand einer einzelnen angebotenen Quest für einen Spieler. */
public final class QuestProgress {

    public enum Status { OFFERED, ACTIVE, COMPLETED, FAILED }

    public final String questId;
    public Status status = Status.OFFERED;
    public int progress;
    /** Rest-Bruchteil (für TRAVEL, damit auch kleine Schritte zählen). */
    public double fraction;
    /** Ablaufzeit in Epoch-Millisekunden, 0 = kein Zeitlimit. */
    public long deadline;
    /** Zeitpunkt des letzten Fortschritts (für die BossBar-Sichtbarkeit). */
    public long lastUpdate;

    public QuestProgress(String questId) {
        this.questId = questId;
    }

    public void resetProgress() {
        progress = 0;
        fraction = 0;
        deadline = 0;
        lastUpdate = 0;
    }
}
