package de.dailyquests;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.minimessage.MiniMessage;
import net.kyori.adventure.text.minimessage.tag.resolver.TagResolver;
import org.bukkit.command.CommandSender;

/** Liest Texte aus der config.yml und wandelt sie per MiniMessage in Komponenten um. */
public final class Messages {

    private static final MiniMessage MM = MiniMessage.miniMessage();

    private final DailyQuestsPlugin plugin;

    public Messages(DailyQuestsPlugin plugin) {
        this.plugin = plugin;
    }

    public String raw(String key) {
        return plugin.getConfig().getString("messages." + key, "<red>[fehlender Text: " + key + "]");
    }

    public Component get(String key, TagResolver... resolvers) {
        return MM.deserialize(raw(key), resolvers);
    }

    public Component prefixed(String key, TagResolver... resolvers) {
        return MM.deserialize(raw("prefix") + raw(key), resolvers);
    }

    public Component parse(String text, TagResolver... resolvers) {
        return MM.deserialize(text, resolvers);
    }

    public void send(CommandSender to, String key, TagResolver... resolvers) {
        to.sendMessage(prefixed(key, resolvers));
    }
}
