package de.dailyquests;

import org.bukkit.Bukkit;
import org.bukkit.command.PluginCommand;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;

import java.io.File;

public final class DailyQuestsPlugin extends JavaPlugin {

    private Messages messages;
    private QuestManager manager;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        if (!new File(getDataFolder(), "quests.yml").exists()) {
            saveResource("quests.yml", false);
        }

        messages = new Messages(this);
        manager = new QuestManager(this);
        manager.reload();

        getServer().getPluginManager().registerEvents(new QuestListener(this), this);
        getServer().getPluginManager().registerEvents(new MenuListener(this), this);

        PluginCommand command = getCommand("quests");
        if (command != null) {
            QuestCommand handler = new QuestCommand(this);
            command.setExecutor(handler);
            command.setTabCompleter(handler);
        }

        // 1x pro Sekunde: Tageswechsel, Zeitlimits, BossBars, offenes Menü aktualisieren
        getServer().getScheduler().runTaskTimer(this, manager::tick, 20L, 20L);
        // alle 5 Minuten geänderte Daten speichern
        getServer().getScheduler().runTaskTimer(this, manager::saveAll, 6000L, 6000L);

        // /reload oder Plugin-Neustart bei laufendem Server
        for (Player player : Bukkit.getOnlinePlayers()) {
            manager.handleJoin(player);
        }
    }

    @Override
    public void onDisable() {
        if (manager != null) {
            manager.shutdown();
        }
    }

    public void reloadAll() {
        reloadConfig();
        manager.reload();
    }

    public Messages messages() {
        return messages;
    }

    public QuestManager manager() {
        return manager;
    }
}
