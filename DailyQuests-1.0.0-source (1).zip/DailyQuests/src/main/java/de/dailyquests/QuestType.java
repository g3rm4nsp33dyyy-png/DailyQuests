package de.dailyquests;

import java.util.Locale;

/** Art einer Quest. Bestimmt, welches Spielereignis den Fortschritt erhöht. */
public enum QuestType {
    BREAK_BLOCK(Kind.BLOCK, "Baue %d Blöcke ab."),
    PLACE_BLOCK(Kind.BLOCK, "Platziere %d Blöcke."),
    KILL_ENTITY(Kind.ENTITY, "Besiege %d Mobs."),
    FISH(Kind.ITEM, "Angle %d Fänge."),
    CRAFT_ITEM(Kind.ITEM, "Stelle %d Items her."),
    SMELT_ITEM(Kind.ITEM, "Schmelze %d Items."),
    BREED_ANIMAL(Kind.ENTITY, "Züchte %d Tiere."),
    TRAVEL(Kind.NONE, "Laufe %d Blöcke weit.");

    /** Was die Einträge unter "targets" bedeuten. */
    public enum Kind { BLOCK, ITEM, ENTITY, NONE }

    private final Kind kind;
    private final String defaultDescription;

    QuestType(Kind kind, String defaultDescription) {
        this.kind = kind;
        this.defaultDescription = defaultDescription;
    }

    public Kind kind() {
        return kind;
    }

    public String defaultDescription(int amount) {
        return String.format(Locale.ROOT, defaultDescription, amount);
    }
}
