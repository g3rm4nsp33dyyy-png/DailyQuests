package de.dailyquests;

import de.dailyquests.QuestProgress.Status;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.TextDecoration;
import net.kyori.adventure.text.minimessage.tag.resolver.Placeholder;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;

import java.util.ArrayList;
import java.util.List;

/** Das Quest-Menü: 3 Quests zur Auswahl, Klick zum Annehmen bzw. Abbrechen. */
public final class QuestMenu implements InventoryHolder {

    private static final int[] QUEST_SLOTS = {11, 13, 15};
    private static final int INFO_SLOT = 22;
    private static final int SIZE = 27;

    private final DailyQuestsPlugin plugin;
    private final Player player;
    private final Inventory inventory;

    public QuestMenu(DailyQuestsPlugin plugin, Player player) {
        this.plugin = plugin;
        this.player = player;
        this.inventory = Bukkit.createInventory(this, SIZE, plugin.messages().get("menu-title"));
    }

    public void open() {
        render();
        player.openInventory(inventory);
    }

    /** Index der Quest (0-2) für einen Slot oder -1. */
    public int indexOfSlot(int slot) {
        for (int i = 0; i < QUEST_SLOTS.length; i++) {
            if (QUEST_SLOTS[i] == slot) {
                return i;
            }
        }
        return -1;
    }

    public void render() {
        QuestManager manager = plugin.manager();
        PlayerData data = manager.data(player);

        ItemStack filler = new ItemStack(Material.GRAY_STAINED_GLASS_PANE);
        filler.editMeta(meta -> meta.displayName(Component.empty()));
        for (int i = 0; i < SIZE; i++) {
            inventory.setItem(i, filler);
        }
        for (int i = 0; i < QUEST_SLOTS.length; i++) {
            if (i < data.quests.size()) {
                ItemStack item = questItem(data.quests.get(i));
                if (item != null) {
                    inventory.setItem(QUEST_SLOTS[i], item);
                }
            } else {
                inventory.setItem(QUEST_SLOTS[i], new ItemStack(Material.AIR));
            }
        }
        inventory.setItem(INFO_SLOT, infoItem(manager, data));
    }

    private ItemStack questItem(QuestProgress qp) {
        Messages messages = plugin.messages();
        QuestDefinition def = plugin.manager().definition(qp.questId);
        if (def == null) {
            return null;
        }

        Material material = qp.status == Status.FAILED ? Material.BARRIER : def.icon();
        ItemStack item = new ItemStack(material);

        List<Component> lore = new ArrayList<>();
        for (String line : def.description()) {
            lore.add(plain(messages.parse("<gray>" + line)));
        }
        lore.add(Component.empty());
        lore.add(plain(messages.get("menu-lore-difficulty",
                Placeholder.parsed("difficulty", plugin.getConfig().getString(
                        "difficulty-names." + def.difficulty().configKey(), def.difficulty().name())))));
        lore.add(plain(messages.get("menu-lore-reward", Placeholder.parsed("xp", String.valueOf(rewardXp(def))))));
        if (def.timeLimitMinutes() > 0) {
            lore.add(plain(messages.get("menu-lore-time-limit",
                    Placeholder.parsed("minutes", String.valueOf(def.timeLimitMinutes())))));
        }
        lore.add(Component.empty());

        boolean glint = false;
        switch (qp.status) {
            case OFFERED -> lore.add(plain(messages.get("menu-lore-accept")));
            case ACTIVE -> {
                glint = true;
                lore.add(plain(messages.get("menu-lore-progress",
                        Placeholder.parsed("progress", String.valueOf(qp.progress)),
                        Placeholder.parsed("amount", String.valueOf(def.amount())),
                        Placeholder.parsed("percent", String.valueOf(Format.percent(qp.progress, def.amount()))))));
                lore.add(plain(messages.parse("<bar>",
                        Placeholder.parsed("bar", Format.bar(qp.progress, def.amount(), 20)))));
                if (qp.deadline > 0) {
                    lore.add(plain(messages.get("menu-lore-time-left",
                            Placeholder.parsed("time", Format.clock(qp.deadline - System.currentTimeMillis())))));
                }
                lore.add(Component.empty());
                if (plugin.getConfig().getBoolean("allow-abandon", true)) {
                    lore.add(plain(messages.get("menu-lore-abandon")));
                }
            }
            case COMPLETED -> {
                glint = true;
                lore.add(plain(messages.get("menu-lore-completed")));
            }
            case FAILED -> lore.add(plain(messages.get("menu-lore-failed")));
        }

        final boolean enchantGlint = glint;
        item.editMeta(meta -> {
            meta.displayName(plain(messages.parse(def.name())));
            meta.lore(lore);
            if (enchantGlint) {
                meta.setEnchantmentGlintOverride(true);
            }
        });
        return item;
    }

    private ItemStack infoItem(QuestManager manager, PlayerData data) {
        Messages messages = plugin.messages();
        ItemStack item = new ItemStack(Material.CLOCK);
        List<Component> lore = new ArrayList<>();
        lore.add(plain(messages.get("menu-info-reset",
                Placeholder.parsed("time", Format.hoursMinutes(manager.untilReset())))));
        lore.add(plain(messages.get("menu-info-today",
                Placeholder.parsed("done", String.valueOf(manager.completedToday(data))),
                Placeholder.parsed("total", String.valueOf(data.quests.size())))));
        lore.add(plain(messages.get("menu-info-total",
                Placeholder.parsed("total", String.valueOf(data.totalCompleted)))));
        item.editMeta(meta -> {
            meta.displayName(plain(messages.get("menu-info-title")));
            meta.lore(lore);
        });
        return item;
    }

    private int rewardXp(QuestDefinition def) {
        return (int) Math.round(def.xp() * plugin.getConfig().getDouble("rewards.xp-multiplier", 1.0));
    }

    /** Entfernt die Standard-Kursivschrift von Item-Namen und -Lore. */
    private static Component plain(Component component) {
        return component.decorationIfAbsent(TextDecoration.ITALIC, TextDecoration.State.FALSE);
    }

    @Override
    public Inventory getInventory() {
        return inventory;
    }
}
