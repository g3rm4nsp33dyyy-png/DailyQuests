package de.dailyquests;

import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.block.Block;
import org.bukkit.block.data.Ageable;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.Item;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.entity.EntityBreedEvent;
import org.bukkit.event.entity.EntityDeathEvent;
import org.bukkit.event.inventory.CraftItemEvent;
import org.bukkit.event.inventory.FurnaceExtractEvent;
import org.bukkit.event.player.PlayerFishEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.ItemStack;

import java.util.function.Predicate;

/** Übersetzt Spielereignisse in Quest-Fortschritt. */
public final class QuestListener implements Listener {

    private static final Predicate<QuestDefinition> ALWAYS = def -> true;

    private final DailyQuestsPlugin plugin;

    public QuestListener(DailyQuestsPlugin plugin) {
        this.plugin = plugin;
    }

    private QuestManager manager() {
        return plugin.manager();
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent event) {
        manager().handleJoin(event.getPlayer());
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent event) {
        manager().handleQuit(event.getPlayer());
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onBreak(BlockBreakEvent event) {
        Block block = event.getBlock();
        // consume() immer aufrufen, damit keine veralteten Markierungen übrig bleiben
        boolean playerPlaced = manager().tracker().consume(block);
        if (playerPlaced && manager().antiExploit()) {
            return;
        }
        Material material = block.getType();
        manager().track(event.getPlayer(), QuestType.BREAK_BLOCK, def -> def.matches(material), 1);
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onPlace(BlockPlaceEvent event) {
        Block block = event.getBlockPlaced();
        // Pflanzen/Saat nicht merken, damit Farm-Quests normal funktionieren
        if (!(block.getBlockData() instanceof Ageable)) {
            manager().tracker().mark(block);
        }
        Material material = block.getType();
        manager().track(event.getPlayer(), QuestType.PLACE_BLOCK, def -> def.matches(material), 1);
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onKill(EntityDeathEvent event) {
        LivingEntity dead = event.getEntity();
        if (dead instanceof Player) {
            return;
        }
        Player killer = dead.getKiller();
        if (killer == null) {
            return;
        }
        EntityType type = dead.getType();
        manager().track(killer, QuestType.KILL_ENTITY, def -> def.matches(type), 1);
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onBreed(EntityBreedEvent event) {
        if (!(event.getBreeder() instanceof Player player)) {
            return;
        }
        EntityType type = event.getEntity().getType();
        manager().track(player, QuestType.BREED_ANIMAL, def -> def.matches(type), 1);
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onFish(PlayerFishEvent event) {
        if (event.getState() != PlayerFishEvent.State.CAUGHT_FISH) {
            return;
        }
        if (!(event.getCaught() instanceof Item caught)) {
            return;
        }
        Material material = caught.getItemStack().getType();
        manager().track(event.getPlayer(), QuestType.FISH, def -> def.matches(material), 1);
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onCraft(CraftItemEvent event) {
        if (!(event.getWhoClicked() instanceof Player player)) {
            return;
        }
        ItemStack result = event.getRecipe().getResult();
        if (result.getType().isAir()) {
            return;
        }
        int amount = result.getAmount();
        if (event.isShiftClick()) {
            // Shift-Klick stellt so oft her, wie das Material im Raster reicht
            int min = Integer.MAX_VALUE;
            for (ItemStack stack : event.getInventory().getMatrix()) {
                if (stack != null && !stack.getType().isAir()) {
                    min = Math.min(min, stack.getAmount());
                }
            }
            if (min != Integer.MAX_VALUE) {
                amount = result.getAmount() * min;
            }
        }
        Material material = result.getType();
        manager().track(player, QuestType.CRAFT_ITEM, def -> def.matches(material), amount);
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onSmelt(FurnaceExtractEvent event) {
        Material material = event.getItemType();
        manager().track(event.getPlayer(), QuestType.SMELT_ITEM, def -> def.matches(material), event.getItemAmount());
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onMove(PlayerMoveEvent event) {
        Location from = event.getFrom();
        Location to = event.getTo();
        if (to == null || from.getBlockX() == to.getBlockX() && from.getBlockZ() == to.getBlockZ()) {
            return;
        }
        if (!from.getWorld().equals(to.getWorld())) {
            return;
        }
        Player player = event.getPlayer();
        if (player.isInsideVehicle() || player.isFlying() || player.isGliding()) {
            return;
        }
        if (!manager().hasActive(player, QuestType.TRAVEL)) {
            return;
        }
        double dx = to.getX() - from.getX();
        double dz = to.getZ() - from.getZ();
        double distance = Math.sqrt(dx * dx + dz * dz);
        if (distance > 8) {
            return; // Teleport
        }
        manager().track(player, QuestType.TRAVEL, ALWAYS, distance);
    }
}
