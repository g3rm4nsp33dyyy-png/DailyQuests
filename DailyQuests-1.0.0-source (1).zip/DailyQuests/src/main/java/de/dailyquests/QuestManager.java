package de.dailyquests;

import de.dailyquests.QuestProgress.Status;
import net.kyori.adventure.bossbar.BossBar;
import net.kyori.adventure.key.Key;
import net.kyori.adventure.sound.Sound;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.minimessage.tag.resolver.Placeholder;
import net.kyori.adventure.title.Title;
import org.bukkit.Bukkit;
import org.bukkit.GameMode;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;

import java.time.DateTimeException;
import java.time.Duration;
import java.time.LocalTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Random;
import java.util.UUID;
import java.util.function.Predicate;

/** Zentrale Logik: Auslosung, Annehmen, Fortschritt, Zeitlimit, Belohnung und BossBars. */
public final class QuestManager {

    private static final int MAX_QUESTS = 3;

    private final DailyQuestsPlugin plugin;
    private final Messages messages;
    private final QuestRegistry registry = new QuestRegistry();
    private final DataStore store;
    private final PlacedBlockTracker tracker = new PlacedBlockTracker();
    private final Map<UUID, PlayerData> cache = new HashMap<>();
    private final Map<UUID, Map<String, BossBar>> bars = new HashMap<>();
    private final Random random = new Random();

    private ZoneId zone = ZoneId.systemDefault();
    private LocalTime resetTime = LocalTime.MIDNIGHT;

    public QuestManager(DailyQuestsPlugin plugin) {
        this.plugin = plugin;
        this.messages = plugin.messages();
        this.store = new DataStore(plugin);
    }

    private FileConfiguration cfg() {
        return plugin.getConfig();
    }

    // ------------------------------------------------------------------ Setup

    public void reload() {
        registry.load(plugin);
        try {
            zone = ZoneId.of(cfg().getString("timezone", "Europe/Berlin"));
        } catch (DateTimeException ex) {
            plugin.getLogger().warning("Ungültige timezone, nutze Systemzeitzone.");
            zone = ZoneId.systemDefault();
        }
        try {
            resetTime = LocalTime.parse(cfg().getString("reset-time", "00:00"));
        } catch (DateTimeException ex) {
            plugin.getLogger().warning("Ungültige reset-time (Format HH:mm), nutze 00:00.");
            resetTime = LocalTime.MIDNIGHT;
        }
        tracker.setMax(cfg().getInt("anti-exploit.max-tracked-blocks", 50_000));

        for (Player player : Bukkit.getOnlinePlayers()) {
            PlayerData data = cache.get(player.getUniqueId());
            if (data != null) {
                validate(data);
                ensureCurrent(player, data);
                refreshBars(player, data);
            }
        }
    }

    public QuestRegistry registry() {
        return registry;
    }

    public PlacedBlockTracker tracker() {
        return tracker;
    }

    public QuestDefinition definition(String id) {
        return registry.get(id);
    }

    public boolean antiExploit() {
        return cfg().getBoolean("anti-exploit.ignore-player-placed-blocks", true);
    }

    // ------------------------------------------------------------------ Zyklus (24h)

    /** Nummer des aktuellen Tages-Zyklus. Wechselt täglich zur reset-time. */
    public long currentCycle() {
        ZonedDateTime now = ZonedDateTime.now(zone);
        return now.minusHours(resetTime.getHour()).minusMinutes(resetTime.getMinute()).toLocalDate().toEpochDay();
    }

    public Duration untilReset() {
        ZonedDateTime now = ZonedDateTime.now(zone);
        ZonedDateTime next = now.toLocalDate().atTime(resetTime).atZone(zone);
        if (!next.isAfter(now)) {
            next = now.toLocalDate().plusDays(1).atTime(resetTime).atZone(zone);
        }
        return Duration.between(now, next);
    }

    // ------------------------------------------------------------------ Spielerdaten

    private PlayerData cached(Player player) {
        return cache.get(player.getUniqueId());
    }

    /** Liefert die Daten des Spielers und lost bei Bedarf (neuer Tag) neue Quests aus. */
    public PlayerData data(Player player) {
        PlayerData data = cache.get(player.getUniqueId());
        if (data == null) {
            data = store.load(player.getUniqueId());
            validate(data);
            cache.put(player.getUniqueId(), data);
        }
        ensureCurrent(player, data);
        return data;
    }

    /** Verwirft Quests, die es in der quests.yml nicht mehr gibt (löst dann neu aus). */
    private void validate(PlayerData data) {
        for (QuestProgress qp : data.quests) {
            if (registry.get(qp.questId) == null) {
                data.cycle = Long.MIN_VALUE;
                return;
            }
        }
    }

    /** @return true, wenn neue Quests ausgelost wurden. */
    private boolean ensureCurrent(Player player, PlayerData data) {
        long cycle = currentCycle();
        if (data.cycle == cycle) {
            return false;
        }
        roll(data);
        data.cycle = cycle;
        data.dirty = true;
        clearBars(player);
        return true;
    }

    private void roll(PlayerData data) {
        int count = Math.max(1, Math.min(MAX_QUESTS, cfg().getInt("quests-per-day", 3)));
        List<QuestDefinition> pool = new ArrayList<>(registry.all());
        Collections.shuffle(pool, random);

        List<QuestDefinition> picked = new ArrayList<>();
        if (cfg().getBoolean("one-per-difficulty", true)) {
            for (Difficulty difficulty : Difficulty.values()) {
                if (picked.size() >= count) {
                    break;
                }
                for (QuestDefinition candidate : pool) {
                    if (candidate.difficulty() == difficulty) {
                        picked.add(candidate);
                        break;
                    }
                }
            }
        }
        for (QuestDefinition candidate : pool) {
            if (picked.size() >= count) {
                break;
            }
            if (!picked.contains(candidate)) {
                picked.add(candidate);
            }
        }
        picked.sort(Comparator.comparing(QuestDefinition::difficulty));

        data.quests.clear();
        for (QuestDefinition def : picked) {
            data.quests.add(new QuestProgress(def.id()));
        }
    }

    /** Lost die Quests eines Spielers sofort neu aus (Admin-Befehl). */
    public void reroll(Player player) {
        PlayerData data = data(player);
        data.cycle = Long.MIN_VALUE;
        ensureCurrent(player, data);
        player.sendMessage(messages.prefixed("new-quests"));
    }

    // ------------------------------------------------------------------ Join / Quit / Speichern

    public void handleJoin(Player player) {
        PlayerData data = data(player);
        refreshBars(player, data);
        long open = data.quests.stream()
                .filter(q -> q.status == Status.OFFERED || q.status == Status.ACTIVE)
                .count();
        if (open > 0) {
            player.sendMessage(messages.prefixed("join-reminder", Placeholder.parsed("count", String.valueOf(open))));
        }
    }

    public void handleQuit(Player player) {
        PlayerData data = cache.remove(player.getUniqueId());
        clearBars(player);
        bars.remove(player.getUniqueId());
        if (data != null) {
            store.save(data, true);
        }
    }

    public void saveAll() {
        for (PlayerData data : cache.values()) {
            if (data.dirty) {
                store.save(data, true);
            }
        }
    }

    public void shutdown() {
        for (PlayerData data : cache.values()) {
            store.save(data, false);
        }
        for (Player player : Bukkit.getOnlinePlayers()) {
            clearBars(player);
        }
        cache.clear();
        bars.clear();
        tracker.clear();
    }

    // ------------------------------------------------------------------ Annehmen / Abbrechen

    public void accept(Player player, int index) {
        PlayerData data = data(player);
        if (index < 0 || index >= data.quests.size()) {
            return;
        }
        QuestProgress qp = data.quests.get(index);
        QuestDefinition def = registry.get(qp.questId);
        if (def == null) {
            return;
        }
        if (qp.status != Status.OFFERED) {
            messages.send(player, "not-offered");
            return;
        }
        int max = Math.max(1, cfg().getInt("max-active-quests", 3));
        long active = data.quests.stream().filter(q -> q.status == Status.ACTIVE).count();
        if (active >= max) {
            messages.send(player, "max-active", Placeholder.parsed("max", String.valueOf(max)));
            return;
        }

        long now = System.currentTimeMillis();
        qp.resetProgress();
        qp.status = Status.ACTIVE;
        qp.lastUpdate = now;
        qp.deadline = def.timeLimitMinutes() > 0 ? now + def.timeLimitMinutes() * 60_000L : 0;
        data.dirty = true;

        messages.send(player, "accepted",
                Placeholder.parsed("quest", def.name()),
                Placeholder.parsed("time", timeLimitSuffix(def)));
        updateBar(player, qp, def);
    }

    public void abandon(Player player, int index) {
        PlayerData data = data(player);
        if (index < 0 || index >= data.quests.size()) {
            return;
        }
        QuestProgress qp = data.quests.get(index);
        QuestDefinition def = registry.get(qp.questId);
        if (def == null || qp.status != Status.ACTIVE) {
            return;
        }
        if (!cfg().getBoolean("allow-abandon", true)) {
            messages.send(player, "abandon-disabled");
            return;
        }
        qp.resetProgress();
        qp.status = Status.OFFERED;
        data.dirty = true;
        hideBar(player, qp.questId);
        messages.send(player, "abandoned", Placeholder.parsed("quest", def.name()));
    }

    // ------------------------------------------------------------------ Fortschritt

    private boolean trackingAllowed(Player player) {
        if (cfg().getBoolean("ignore-creative", true) && player.getGameMode() == GameMode.CREATIVE) {
            return false;
        }
        return !cfg().getStringList("disabled-worlds").contains(player.getWorld().getName());
    }

    public boolean hasActive(Player player, QuestType type) {
        PlayerData data = cached(player);
        if (data == null) {
            return false;
        }
        for (QuestProgress qp : data.quests) {
            if (qp.status == Status.ACTIVE) {
                QuestDefinition def = registry.get(qp.questId);
                if (def != null && def.type() == type) {
                    return true;
                }
            }
        }
        return false;
    }

    /**
     * Erhöht den Fortschritt aller aktiven Quests des Typs, deren Ziel zum Filter passt.
     * amount darf ein Bruchteil sein (TRAVEL).
     */
    public void track(Player player, QuestType type, Predicate<QuestDefinition> filter, double amount) {
        PlayerData data = cached(player);
        if (data == null || !trackingAllowed(player)) {
            return;
        }
        long now = System.currentTimeMillis();
        // Kopie, weil complete() die Liste nicht verändert, aber sicher ist sicher
        for (QuestProgress qp : new ArrayList<>(data.quests)) {
            if (qp.status != Status.ACTIVE) {
                continue;
            }
            QuestDefinition def = registry.get(qp.questId);
            if (def == null || def.type() != type || !filter.test(def)) {
                continue;
            }
            if (qp.deadline > 0 && now >= qp.deadline) {
                continue; // wird im nächsten tick() als fehlgeschlagen markiert
            }
            qp.fraction += amount;
            int whole = (int) qp.fraction;
            if (whole <= 0) {
                continue;
            }
            qp.fraction -= whole;
            qp.progress = Math.min(def.amount(), qp.progress + whole);
            qp.lastUpdate = now;
            data.dirty = true;
            if (qp.progress >= def.amount()) {
                complete(player, data, qp, def);
            } else {
                updateBar(player, qp, def);
            }
        }
    }

    private void complete(Player player, PlayerData data, QuestProgress qp, QuestDefinition def) {
        qp.status = Status.COMPLETED;
        qp.progress = def.amount();
        data.totalCompleted++;
        data.dirty = true;
        hideBar(player, qp.questId);

        int xp = (int) Math.round(def.xp() * cfg().getDouble("rewards.xp-multiplier", 1.0));
        if (xp > 0) {
            player.giveExp(xp);
        }

        var quest = Placeholder.parsed("quest", def.name());
        var xpPlaceholder = Placeholder.parsed("xp", String.valueOf(xp));
        player.sendMessage(messages.prefixed("completed", quest, xpPlaceholder));
        if (cfg().getBoolean("rewards.show-title", true)) {
            player.showTitle(Title.title(
                    messages.get("completed-title"),
                    messages.get("completed-subtitle", quest, xpPlaceholder),
                    Title.Times.times(Duration.ofMillis(300), Duration.ofSeconds(2), Duration.ofMillis(500))));
        }
        String soundKey = cfg().getString("rewards.sound", "");
        if (soundKey != null && !soundKey.isBlank()) {
            try {
                player.playSound(Sound.sound(Key.key(soundKey.toLowerCase(Locale.ROOT)), Sound.Source.PLAYER, 1f, 1f));
            } catch (RuntimeException ex) {
                plugin.getLogger().warning("Ungültiger Sound in rewards.sound: " + soundKey);
            }
        }
    }

    private void fail(Player player, PlayerData data, QuestProgress qp, QuestDefinition def) {
        qp.status = Status.FAILED;
        data.dirty = true;
        hideBar(player, qp.questId);
        messages.send(player, "failed", Placeholder.parsed("quest", def.name()));
    }

    // ------------------------------------------------------------------ Tick (1x pro Sekunde)

    public void tick() {
        long now = System.currentTimeMillis();
        for (Player player : Bukkit.getOnlinePlayers()) {
            PlayerData data = cache.get(player.getUniqueId());
            if (data == null) {
                continue;
            }
            if (ensureCurrent(player, data)) {
                player.sendMessage(messages.prefixed("new-quests"));
            }
            for (QuestProgress qp : data.quests) {
                if (qp.status != Status.ACTIVE) {
                    continue;
                }
                QuestDefinition def = registry.get(qp.questId);
                if (def == null) {
                    continue;
                }
                if (qp.deadline > 0 && now >= qp.deadline) {
                    fail(player, data, qp, def);
                } else {
                    updateBar(player, qp, def);
                }
            }
            if (player.getOpenInventory().getTopInventory().getHolder() instanceof QuestMenu menu) {
                menu.render();
            }
        }
    }

    // ------------------------------------------------------------------ BossBars

    private String timeLimitSuffix(QuestDefinition def) {
        if (def.timeLimitMinutes() <= 0) {
            return "";
        }
        return messages.raw("time-limit-suffix").replace("<minutes>", String.valueOf(def.timeLimitMinutes()));
    }

    private void refreshBars(Player player, PlayerData data) {
        for (QuestProgress qp : data.quests) {
            QuestDefinition def = registry.get(qp.questId);
            if (def != null) {
                updateBar(player, qp, def);
            }
        }
    }

    private void updateBar(Player player, QuestProgress qp, QuestDefinition def) {
        if (!cfg().getBoolean("bossbar.enabled", true)) {
            return;
        }
        long now = System.currentTimeMillis();
        boolean always = cfg().getBoolean("bossbar.always-visible", true);
        long hideAfter = cfg().getLong("bossbar.hide-after-seconds", 8) * 1000L;
        boolean visible = qp.status == Status.ACTIVE && (always || now - qp.lastUpdate < hideAfter);

        Map<String, BossBar> playerBars = bars.computeIfAbsent(player.getUniqueId(), k -> new HashMap<>());
        BossBar bar = playerBars.get(qp.questId);
        if (!visible) {
            if (bar != null) {
                player.hideBossBar(bar);
                playerBars.remove(qp.questId);
            }
            return;
        }

        float fill = Math.max(0f, Math.min(1f, qp.progress / (float) def.amount()));
        String timeText = "";
        if (qp.deadline > 0) {
            timeText = messages.raw("time-left-suffix").replace("<time>", Format.clock(qp.deadline - now));
        }
        Component title = messages.get("bossbar",
                Placeholder.parsed("quest", def.name()),
                Placeholder.parsed("progress", String.valueOf(qp.progress)),
                Placeholder.parsed("amount", String.valueOf(def.amount())),
                Placeholder.parsed("percent", String.valueOf(Format.percent(qp.progress, def.amount()))),
                Placeholder.parsed("time", timeText));

        if (bar == null) {
            BossBar.Overlay overlay;
            try {
                overlay = BossBar.Overlay.valueOf(cfg().getString("bossbar.style", "NOTCHED_10").toUpperCase(Locale.ROOT));
            } catch (IllegalArgumentException ex) {
                overlay = BossBar.Overlay.NOTCHED_10;
            }
            bar = BossBar.bossBar(title, fill, def.difficulty().barColor(), overlay);
            playerBars.put(qp.questId, bar);
            player.showBossBar(bar);
        } else {
            bar.name(title);
            bar.progress(fill);
        }
    }

    private void hideBar(Player player, String questId) {
        Map<String, BossBar> playerBars = bars.get(player.getUniqueId());
        if (playerBars == null) {
            return;
        }
        BossBar bar = playerBars.remove(questId);
        if (bar != null) {
            player.hideBossBar(bar);
        }
    }

    private void clearBars(Player player) {
        Map<String, BossBar> playerBars = bars.get(player.getUniqueId());
        if (playerBars == null) {
            return;
        }
        for (BossBar bar : playerBars.values()) {
            player.hideBossBar(bar);
        }
        playerBars.clear();
    }

    // ------------------------------------------------------------------ Hilfen für das Menü

    public int completedToday(PlayerData data) {
        int done = 0;
        for (QuestProgress qp : data.quests) {
            if (qp.status == Status.COMPLETED) {
                done++;
            }
        }
        return done;
    }

    public Collection<Player> onlinePlayers() {
        return new ArrayList<>(Bukkit.getOnlinePlayers());
    }
}
