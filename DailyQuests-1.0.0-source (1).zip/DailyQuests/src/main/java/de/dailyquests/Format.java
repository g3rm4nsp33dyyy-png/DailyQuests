package de.dailyquests;

import java.time.Duration;
import java.util.Locale;

/** Kleine Hilfsfunktionen für Zeit- und Balkenanzeigen. */
public final class Format {

    private Format() {
    }

    /** 75000 ms -> "01:15", ab einer Stunde "1:02:03". */
    public static String clock(long millis) {
        long s = Math.max(0, millis / 1000);
        long h = s / 3600;
        long m = (s % 3600) / 60;
        long sec = s % 60;
        if (h > 0) {
            return String.format(Locale.ROOT, "%d:%02d:%02d", h, m, sec);
        }
        return String.format(Locale.ROOT, "%02d:%02d", m, sec);
    }

    /** Dauer als "5h 12m". */
    public static String hoursMinutes(Duration d) {
        long minutes = Math.max(0, d.toMinutes());
        return (minutes / 60) + "h " + (minutes % 60) + "m";
    }

    public static int percent(int value, int max) {
        if (max <= 0) {
            return 0;
        }
        return (int) Math.min(100, Math.round(100.0 * value / max));
    }

    /** Textbalken, z.B. ██████░░░░ (MiniMessage-Farben). */
    public static String bar(int value, int max, int length) {
        int filled = max <= 0 ? 0 : (int) Math.round((double) length * Math.min(value, max) / max);
        filled = Math.max(0, Math.min(length, filled));
        return "<green>" + "█".repeat(filled) + "</green><dark_gray>" + "░".repeat(length - filled) + "</dark_gray>";
    }
}
