package de.dailyquests;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

/** Alle gespeicherten Quest-Daten eines Spielers. */
public final class PlayerData {

    public final UUID uuid;
    /** Tages-Zyklus, für den die Quests ausgelost wurden. */
    public long cycle = Long.MIN_VALUE;
    public int totalCompleted;
    public final List<QuestProgress> quests = new ArrayList<>();
    public boolean dirty;

    public PlayerData(UUID uuid) {
        this.uuid = uuid;
    }
}
