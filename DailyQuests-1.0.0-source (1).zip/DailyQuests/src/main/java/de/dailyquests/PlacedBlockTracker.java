package de.dailyquests;

import org.bukkit.block.Block;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.UUID;

/**
 * Merkt sich (begrenzt) welche Blöcke von Spielern platziert wurden,
 * damit Platzieren/Abbauen nicht für BREAK_BLOCK-Quests ausgenutzt werden kann.
 */
public final class PlacedBlockTracker {

    private record Key(UUID world, long position) {
    }

    private volatile int max = 50_000;

    private final Map<Key, Boolean> placed = new LinkedHashMap<>(1024, 0.75f, false) {
        @Override
        protected boolean removeEldestEntry(Map.Entry<Key, Boolean> eldest) {
            return size() > max;
        }
    };

    public void setMax(int max) {
        this.max = Math.max(1000, max);
    }

    public void mark(Block block) {
        placed.put(new Key(block.getWorld().getUID(), block.getBlockKey()), Boolean.TRUE);
    }

    /** Entfernt die Markierung und gibt zurück, ob der Block von einem Spieler platziert worden war. */
    public boolean consume(Block block) {
        return placed.remove(new Key(block.getWorld().getUID(), block.getBlockKey())) != null;
    }

    public void clear() {
        placed.clear();
    }
}
