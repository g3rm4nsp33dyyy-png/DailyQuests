package de.dailyquests;

import net.kyori.adventure.text.minimessage.tag.resolver.Placeholder;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabExecutor;
import org.bukkit.entity.Player;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/** /quests, /quests reload, /quests reroll [spieler] */
public final class QuestCommand implements TabExecutor {

    private final DailyQuestsPlugin plugin;

    public QuestCommand(DailyQuestsPlugin plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        Messages messages = plugin.messages();

        if (args.length == 0) {
            if (!(sender instanceof Player player)) {
                messages.send(sender, "players-only");
                return true;
            }
            if (!player.hasPermission("dailyquests.use")) {
                messages.send(player, "no-permission");
                return true;
            }
            new QuestMenu(plugin, player).open();
            return true;
        }

        String sub = args[0].toLowerCase(Locale.ROOT);
        switch (sub) {
            case "reload" -> {
                if (!sender.hasPermission("dailyquests.admin")) {
                    messages.send(sender, "no-permission");
                    return true;
                }
                plugin.reloadAll();
                messages.send(sender, "reloaded",
                        Placeholder.parsed("count", String.valueOf(plugin.manager().registry().size())));
            }
            case "reroll" -> {
                if (!sender.hasPermission("dailyquests.admin")) {
                    messages.send(sender, "no-permission");
                    return true;
                }
                Player target;
                if (args.length >= 2) {
                    target = Bukkit.getPlayerExact(args[1]);
                } else if (sender instanceof Player self) {
                    target = self;
                } else {
                    messages.send(sender, "usage");
                    return true;
                }
                if (target == null) {
                    messages.send(sender, "player-not-found");
                    return true;
                }
                plugin.manager().reroll(target);
                messages.send(sender, "rerolled", Placeholder.parsed("player", target.getName()));
            }
            default -> messages.send(sender, "usage");
        }
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        List<String> result = new ArrayList<>();
        if (!sender.hasPermission("dailyquests.admin")) {
            return result;
        }
        if (args.length == 1) {
            for (String option : List.of("reload", "reroll")) {
                if (option.startsWith(args[0].toLowerCase(Locale.ROOT))) {
                    result.add(option);
                }
            }
        } else if (args.length == 2 && args[0].equalsIgnoreCase("reroll")) {
            for (Player player : Bukkit.getOnlinePlayers()) {
                if (player.getName().toLowerCase(Locale.ROOT).startsWith(args[1].toLowerCase(Locale.ROOT))) {
                    result.add(player.getName());
                }
            }
        }
        return result;
    }
}
