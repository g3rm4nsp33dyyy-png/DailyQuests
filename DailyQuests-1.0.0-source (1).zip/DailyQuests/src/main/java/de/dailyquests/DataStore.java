package de.dailyquests;

import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;

import java.io.File;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.StandardCopyOption;
import java.util.UUID;
import java.util.logging.Level;

/** Speichert Spielerdaten als YAML-Datei pro Spieler (plugins/DailyQuests/data/UUID.yml). */
public final class DataStore {

    private final DailyQuestsPlugin plugin;
    private final File dir;

    public DataStore(DailyQuestsPlugin plugin) {
        this.plugin = plugin;
        this.dir = new File(plugin.getDataFolder(), "data");
        if (!dir.exists() && !dir.mkdirs()) {
            plugin.getLogger().warning("Konnte Datenordner nicht erstellen: " + dir);
        }
    }

    private File file(UUID uuid) {
        return new File(dir, uuid + ".yml");
    }

    public PlayerData load(UUID uuid) {
        PlayerData data = new PlayerData(uuid);
        File file = file(uuid);
        if (!file.exists()) {
            return data;
        }
        YamlConfiguration yaml = YamlConfiguration.loadConfiguration(file);
        data.cycle = yaml.getLong("cycle", Long.MIN_VALUE);
        data.totalCompleted = yaml.getInt("total-completed", 0);
        ConfigurationSection quests = yaml.getConfigurationSection("quests");
        if (quests != null) {
            for (String key : quests.getKeys(false)) {
                ConfigurationSection s = quests.getConfigurationSection(key);
                if (s == null) {
                    continue;
                }
                String id = s.getString("id");
                if (id == null) {
                    continue;
                }
                QuestProgress qp = new QuestProgress(id);
                try {
                    qp.status = QuestProgress.Status.valueOf(s.getString("status", "OFFERED"));
                } catch (IllegalArgumentException ex) {
                    qp.status = QuestProgress.Status.OFFERED;
                }
                qp.progress = s.getInt("progress", 0);
                qp.fraction = s.getDouble("fraction", 0);
                qp.deadline = s.getLong("deadline", 0);
                data.quests.add(qp);
            }
        }
        return data;
    }

    private String serialize(PlayerData data) {
        YamlConfiguration yaml = new YamlConfiguration();
        yaml.set("cycle", data.cycle);
        yaml.set("total-completed", data.totalCompleted);
        int i = 0;
        for (QuestProgress qp : data.quests) {
            String base = "quests." + i++;
            yaml.set(base + ".id", qp.questId);
            yaml.set(base + ".status", qp.status.name());
            yaml.set(base + ".progress", qp.progress);
            yaml.set(base + ".fraction", qp.fraction);
            yaml.set(base + ".deadline", qp.deadline);
        }
        return yaml.saveToString();
    }

    /** Speichert die Daten. Mit async = true läuft nur das Schreiben der Datei in einem Hintergrund-Thread. */
    public void save(PlayerData data, boolean async) {
        String content = serialize(data);
        File target = file(data.uuid);
        data.dirty = false;
        if (async) {
            plugin.getServer().getScheduler().runTaskAsynchronously(plugin, () -> write(target, content));
        } else {
            write(target, content);
        }
    }

    private void write(File target, String content) {
        try {
            File tmp = new File(target.getParentFile(), target.getName() + ".tmp");
            Files.writeString(tmp.toPath(), content, StandardCharsets.UTF_8);
            Files.move(tmp.toPath(), target.toPath(), StandardCopyOption.REPLACE_EXISTING);
        } catch (IOException ex) {
            plugin.getLogger().log(Level.SEVERE, "Konnte " + target.getName() + " nicht speichern", ex);
        }
    }
}
