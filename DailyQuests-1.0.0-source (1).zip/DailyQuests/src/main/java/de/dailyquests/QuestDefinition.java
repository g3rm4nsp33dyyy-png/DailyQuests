package de.dailyquests;

import org.bukkit.Material;
import org.bukkit.Tag;
import org.bukkit.entity.EntityType;

import java.util.List;
import java.util.Set;

/** Eine Quest-Vorlage aus der quests.yml. */
public record QuestDefinition(
        String id,
        String name,
        List<String> description,
        QuestType type,
        boolean any,
        Set<String> targets,
        List<Tag<Material>> tags,
        int amount,
        int xp,
        int timeLimitMinutes,
        Difficulty difficulty,
        Material icon) {

    public boolean matches(Material material) {
        if (any) {
            return true;
        }
        if (targets.contains(material.getKey().getKey())) {
            return true;
        }
        for (Tag<Material> tag : tags) {
            if (tag.isTagged(material)) {
                return true;
            }
        }
        return false;
    }

    public boolean matches(EntityType entityType) {
        return any || targets.contains(entityType.getKey().getKey());
    }
}
