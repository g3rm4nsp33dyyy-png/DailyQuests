package de.dailyquests;

import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.ClickType;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;

/** Klicks im Quest-Menü. */
public final class MenuListener implements Listener {

    private final DailyQuestsPlugin plugin;

    public MenuListener(DailyQuestsPlugin plugin) {
        this.plugin = plugin;
    }

    @EventHandler
    public void onClick(InventoryClickEvent event) {
        if (!(event.getView().getTopInventory().getHolder() instanceof QuestMenu menu)) {
            return;
        }
        event.setCancelled(true);
        if (event.getClickedInventory() != event.getView().getTopInventory()) {
            return;
        }
        if (!(event.getWhoClicked() instanceof Player player)) {
            return;
        }
        int index = menu.indexOfSlot(event.getSlot());
        if (index < 0) {
            return;
        }
        ClickType click = event.getClick();
        if (click.isLeftClick()) {
            plugin.manager().accept(player, index);
        } else if (click.isRightClick()) {
            plugin.manager().abandon(player, index);
        }
        menu.render();
    }

    @EventHandler
    public void onDrag(InventoryDragEvent event) {
        if (event.getView().getTopInventory().getHolder() instanceof QuestMenu) {
            event.setCancelled(true);
        }
    }
}
