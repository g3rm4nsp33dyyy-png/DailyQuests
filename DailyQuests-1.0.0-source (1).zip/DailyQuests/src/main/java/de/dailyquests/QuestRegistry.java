package de.dailyquests;

import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.Tag;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;

import java.io.File;
import java.util.ArrayList;
import java.util.Collection;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

/** Lädt und hält alle Quest-Vorlagen aus der quests.yml. */
public final class QuestRegistry {

    private final Map<String, QuestDefinition> quests = new LinkedHashMap<>();

    public void load(DailyQuestsPlugin plugin) {
        quests.clear();
        File file = new File(plugin.getDataFolder(), "quests.yml");
        YamlConfiguration yaml = YamlConfiguration.loadConfiguration(file);
        ConfigurationSection root = yaml.getConfigurationSection("quests");
        if (root == null) {
            plugin.getLogger().warning("quests.yml enthält keinen 'quests'-Abschnitt.");
            return;
        }
        for (String id : root.getKeys(false)) {
            ConfigurationSection section = root.getConfigurationSection(id);
            if (section == null) {
                continue;
            }
            try {
                quests.put(id, parse(id, section));
            } catch (IllegalArgumentException ex) {
                plugin.getLogger().warning("Quest '" + id + "' übersprungen: " + ex.getMessage());
            }
        }
        plugin.getLogger().info(quests.size() + " Quests geladen.");
    }

    private QuestDefinition parse(String id, ConfigurationSection s) {
        String typeName = s.getString("type", "").toUpperCase(Locale.ROOT);
        QuestType type;
        try {
            type = QuestType.valueOf(typeName);
        } catch (IllegalArgumentException ex) {
            throw new IllegalArgumentException("Unbekannter type '" + typeName + "'");
        }

        int amount = s.getInt("amount", 1);
        if (amount < 1) {
            throw new IllegalArgumentException("amount muss mindestens 1 sein");
        }
        int xp = Math.max(0, s.getInt("xp", 10));
        int timeLimit = Math.max(0, s.getInt("time-limit-minutes", 0));

        Difficulty difficulty;
        String diffName = s.getString("difficulty", "MEDIUM").toUpperCase(Locale.ROOT);
        try {
            difficulty = Difficulty.valueOf(diffName);
        } catch (IllegalArgumentException ex) {
            throw new IllegalArgumentException("Unbekannte difficulty '" + diffName + "'");
        }

        List<String> rawTargets = new ArrayList<>();
        if (s.isList("targets")) {
            rawTargets.addAll(s.getStringList("targets"));
        } else if (s.isString("targets")) {
            rawTargets.add(s.getString("targets"));
        } else if (s.isString("target")) {
            rawTargets.add(s.getString("target"));
        }

        boolean any = rawTargets.isEmpty() || type.kind() == QuestType.Kind.NONE;
        Set<String> targets = new LinkedHashSet<>();
        List<Tag<Material>> tags = new ArrayList<>();
        for (String raw : rawTargets) {
            String value = raw.trim().toLowerCase(Locale.ROOT);
            if (value.equals("any")) {
                any = true;
            } else if (value.startsWith("#")) {
                tags.add(resolveTag(type, value.substring(1)));
            } else {
                targets.add(value.startsWith("minecraft:") ? value.substring("minecraft:".length()) : value);
            }
        }

        List<String> description = new ArrayList<>();
        if (s.isList("description")) {
            description.addAll(s.getStringList("description"));
        } else if (s.isString("description")) {
            description.add(s.getString("description"));
        }
        if (description.isEmpty()) {
            description.add(type.defaultDescription(amount));
        }

        Material icon = Material.matchMaterial(s.getString("icon", "PAPER"));
        if (icon == null || icon.isAir()) {
            icon = Material.PAPER;
        }

        String name = s.getString("name", id);
        return new QuestDefinition(id, name, List.copyOf(description), type, any,
                Set.copyOf(targets), List.copyOf(tags), amount, xp, timeLimit, difficulty, icon);
    }

    private Tag<Material> resolveTag(QuestType type, String name) {
        String key = name.startsWith("minecraft:") ? name.substring("minecraft:".length()) : name;
        String registry;
        switch (type.kind()) {
            case BLOCK -> registry = Tag.REGISTRY_BLOCKS;
            case ITEM -> registry = Tag.REGISTRY_ITEMS;
            default -> throw new IllegalArgumentException("Tags (#" + name + ") sind für diesen Quest-Typ nicht möglich");
        }
        Tag<Material> tag = Bukkit.getTag(registry, NamespacedKey.minecraft(key), Material.class);
        if (tag == null) {
            throw new IllegalArgumentException("Unbekannter Tag '#" + name + "'");
        }
        return tag;
    }

    public QuestDefinition get(String id) {
        return quests.get(id);
    }

    public Collection<QuestDefinition> all() {
        return quests.values();
    }

    public int size() {
        return quests.size();
    }
}
