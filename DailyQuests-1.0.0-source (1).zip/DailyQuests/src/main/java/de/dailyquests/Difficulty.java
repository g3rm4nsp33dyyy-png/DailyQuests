package de.dailyquests;

import net.kyori.adventure.bossbar.BossBar;

public enum Difficulty {
    EASY("easy", BossBar.Color.GREEN),
    MEDIUM("medium", BossBar.Color.YELLOW),
    HARD("hard", BossBar.Color.RED);

    private final String configKey;
    private final BossBar.Color barColor;

    Difficulty(String configKey, BossBar.Color barColor) {
        this.configKey = configKey;
        this.barColor = barColor;
    }

    public String configKey() {
        return configKey;
    }

    public BossBar.Color barColor() {
        return barColor;
    }
}
