rootProject.name = "DailyQuests"
